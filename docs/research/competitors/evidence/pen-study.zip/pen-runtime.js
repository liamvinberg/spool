/**
 * @schema 2.11
 * @input count: number = 1
 * @input label: string = "Saved"
 */
return [{ type: 'frame', name: 'Script output', width: pencil.width,
  height: pencil.height, fill: '#FFFFFF', layout: 'vertical', padding: 16,
  children: [{ type: 'text', name: 'Runtime status',
    content: pencil.input.label + ': ' + pencil.input.count,
    fontFamily: 'Inter', fontSize: 20, fill: '#151515' }] }];
